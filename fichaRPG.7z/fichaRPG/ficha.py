import os
os.system('cls')


print('Está sera a minha ficha de personagem de jogo RPG')

print('--------------------------------')


print('Qual o genero do seu personagem?')
genero = input('[M] ou [F] -> Resposta: ')
if genero == 'M' or genero == 'F':
    nome_personagem = input('Qual o nome do seu personagem? ')
    especie_personagem = input('Qual a espécie do seu personagem? ')
    classe_personagem = input('Qual a classe do seu personagem? ')

else:
    print('Valor não reconhecido.'); 

print('Nome do personagem é', nome_personagem)
print('Espécie do personagem', especie_personagem)
print('A classe do personagem é', classe_personagem)





# genero
# nome
# especie
# classe